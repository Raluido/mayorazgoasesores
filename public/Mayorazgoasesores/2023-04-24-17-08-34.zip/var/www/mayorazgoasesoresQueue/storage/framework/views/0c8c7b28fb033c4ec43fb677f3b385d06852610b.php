<?php $__env->startSection('content'); ?>
<section class="noticiasAll">
    <div class="innerNoticias">
        <div class="top">
            <img src="<?php echo e(Storage::url('design/noticias.jpg')); ?>" alt="" class="">
        </div>
        <div class="bottom">
            <div class="innerBottom">
                <div class="">
                    <h1>Todas las noticias</h1>
                </div>
                <?php if(empty($posts[0])): ?>
                <div class="noNews">
                    <p>Por ahora no hay noticias subidas, pronto tendremos la actualidad!!</p>
                </div>
                <?php else: ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="news">
                    <div class="title" style="margin-bottom:2em;">
                        <h1 class=""><?php echo e($post->title); ?></h1>
                    </div>
                    <div class="subtitle">
                        <p class=""><?php echo e($post->subtitle); ?></p>
                    </div>
                    <hr>
                    <div class="content">
                        <p class=""><?php echo nl2br(e($post->body)); ?></p>
                    </div>
                    <div class="date">
                        <h5>Publicado en: <?php echo e(date('Y-m-d', strtotime($post->published_at))); ?></h5>
                    </div>
                    <div class="gotoNoticia">
                        <button class="gray stylingButtons"><a href="<?php echo e(route('posts.show', $post->id)); ?>" class="buttonTextWt">Ir a noticia</a></button>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="bottomNav">
                    <button class="stylingButtons blue"><a href="<?php echo e(route('home.index')); ?>" class="buttonTextWt">Volver</a></button>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/mayorazgoasesoresQueue/resources/views/posts/showAll.blade.php ENDPATH**/ ?>