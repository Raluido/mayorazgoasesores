<?php $__env->startSection('content'); ?>
<section class="login">
    <form method="post" action="<?php echo e(route('login.perform')); ?>">

        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

        <h1 class="">Login</h1>

        <div class="">
            <div class="">

                <!-- <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->

                <div class="inputDiv">
                    <input type="text" class="" name="nif" value="<?php echo e(old('nif')); ?>" placeholder="Email o nif" required="required" autofocus>
                    <label for="floatingName">Email o Nif</label>
                    <?php if($errors->has('nif')): ?>
                    <span class="red" style="display:block;"><?php echo e($errors->first('nif')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="inputDiv">
                    <input type="password" class="" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required="required">
                    <label for="floatingPassword">Contraseña</label>
                    <?php if($errors->has('password')): ?>
                    <span class="red" style="display:block;"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="inputDiv">
                    <button class="" type="submit">Login</button>
                    <div class="forgetPass">
                        <label class="">
                            <a class="" href="<?php echo e(route('forget.password.get')); ?>">Olvidé la
                                contraseña</a>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <!-- <?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/mayorazgoasesoresQueue/resources/views/auth/login.blade.php ENDPATH**/ ?>