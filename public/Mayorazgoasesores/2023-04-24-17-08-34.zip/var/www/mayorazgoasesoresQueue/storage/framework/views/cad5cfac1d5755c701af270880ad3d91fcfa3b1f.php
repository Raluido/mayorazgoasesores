<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Websiwebs">
    <title>mayorazgo asesores</title>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

</head>

<body class="">

    <main class="form-signin">

        <?php echo $__env->yieldContent('content'); ?>

    </main>

</body>

</html><?php /**PATH /var/www/mayorazgoasesoresQueue/resources/views/layouts/auth-master.blade.php ENDPATH**/ ?>