<h4>Error en la carga de documentos</h4>

<p>{{ $jobError }}</p>



<h4>Estos son los errores que hemos registrado, si se repite el error envíe éste email al administrador del sistema, gracias!</h4>

<p>{{ $exception }}</p>
