<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Websiwebs">
    <title>mayorazgo asesores</title>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('storage/design/myriadFont/style.css')); ?>" />

</head>

<body>

    <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="<?php echo e(asset('js/jquery-3.6.4.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('js/mobileMenu.js')); ?>"></script>
    <?php $__env->startSection('scripts'); ?>
    <?php echo $__env->yieldSection(); ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH /var/www/mayorazgoasesoresQueue/resources/views/layouts/app-master.blade.php ENDPATH**/ ?>