<p class="">&copy; <?php echo e(date('Y')); ?></p>
<?php /**PATH /var/www/mayorazgoasesoresQueue/resources/views/auth/partials/copy.blade.php ENDPATH**/ ?>