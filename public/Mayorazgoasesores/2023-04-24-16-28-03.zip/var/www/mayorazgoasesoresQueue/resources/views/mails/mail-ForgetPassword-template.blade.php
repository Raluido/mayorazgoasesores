<h1>Reseteo de contraseña</h1>

Puedes restaurar la contraseña en el siguiente enlace:
<a href="{{ route('reset.password.get', $token) }}">Resetear Contraseña</a>
