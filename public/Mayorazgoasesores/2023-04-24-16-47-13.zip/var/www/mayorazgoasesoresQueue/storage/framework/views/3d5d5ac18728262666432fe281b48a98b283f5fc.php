<header class="">
    <nav class="">
        <div class="innerNav">
            <div class="logoMenu">
                <a href="<?php echo e(route('home.index')); ?>" class="">
                    <div class="logo">
                        <div class="imageLogo"><img src="<?php echo e(Storage::url('design/logoFixed.jpg')); ?>" alt="" class=""></div>
                        <div class="nameLogo">
                            <h3 class="">mayorago<br><span>asesores</span></h3>
                        </div>
                    </div>
                </a>
                <div class="menu">
                    <ul class="">
                        <li class=""><a class="" href="<?php echo e(route('home.index')); ?>">Inicio</a></li>
                        <li class=""><a class="" href="/#equipo">Equipo</a></li>
                        <li class=""><a class="" href="/#servicios">Servicios</a></li>
                        <li class=""><a class="" href="/#noticias">Noticias</a></li>
                        <li class=""><a class="" href="/#contacto">Contacto</a></li>
                    </ul>
                </div>
            </div>
            <div class="intranetMenu">
                <div class="innerIntranetMenu">
                    <button class="intranetMenuBtn" onclick="openMenuIntranet()" type="button">Intranet</button>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                    <div class="dropdownIntranet" id="myDropdownIntranet">
                        <p class="logued">Bienvenido <?php echo e(auth()->user()->name); ?></p>
                        <hr><br>
                        <a href="<?php echo e(route('intranet.index')); ?>" class="dropdown-item">Intranet</a>
                        <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item">Salir</a>
                    </div>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'user')): ?>
                    <div class="dropdownIntranet" id="myDropdownIntranet">
                        <p class="logued">Bienvenido <?php echo e(auth()->user()->name); ?></p>
                        <hr><br>
                        <a href="<?php echo e(route('intranet.index')); ?>" class="dropdown-item">Intranet</a>
                        <a class="dropdown-item" href="<?php echo e(route('user.editData')); ?>">Panel usuario</a>
                        <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item">Salir</a>
                    </div>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'asesor')): ?>
                    <div class="dropdownIntranet" id="myDropdownIntranet">
                        <p class="logued">Bienvenido <?php echo e(auth()->user()->name); ?></p>
                        <hr><br>
                        <a href="<?php echo e(route('intranet.index')); ?>" class="dropdown-item">Intranet</a>
                        <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item">Salir</a>
                    </div>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'contable')): ?>
                    <div class="dropdownIntranet" id="myDropdownIntranet">
                        <p class="logued">Bienvenido <?php echo e(auth()->user()->name); ?></p>
                        <hr><br>
                        <a href="<?php echo e(route('intranet.index')); ?>" class="dropdown-item">Intranet</a>
                        <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item">Salir</a>
                    </div>
                    <?php endif; ?>

                    <?php endif; ?>

                    <?php if(auth()->guard()->guest()): ?>
                    <div class="dropdownIntranet" id="myDropdownIntranet">
                        <a href="<?php echo e(route('login.perform')); ?>" class="btn btn-outline-light me-2">Login</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="mobileMenu">
                <div class="innerMobileMenu">
                    <button class="mobileMenuBtn" onclick="openMenu()" type="button"><img src="<?php echo e(Storage::url('design/mobileMenu.png')); ?>" alt="" class=""></button>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                    <div class="dropdown" id="myDropdown">
                        <p class="logued">Bienvenido <?php echo e(auth()->user()->name); ?></p>
                        <hr><br>
                        <a href="<?php echo e(route('intranet.index')); ?>" class="dropdown-item">Intranet</a>
                        <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item">Salir</a>
                        <hr><br>
                        <a class="" href="<?php echo e(route('home.index')); ?>">Inicio</a>
                        <a class="" href="/#equipo">Equipo</a>
                        <a class="" href="/#servicios">Servicios</a>
                        <a class="" href="/#noticias">Noticias</a>
                        <a class="" href="/#contacto">Contacto</a>
                    </div>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'user')): ?>
                    <div class="dropdown" id="myDropdown">
                        <p class="logued">Bienvenido <?php echo e(auth()->user()->name); ?></p>
                        <hr><br>
                        <a href="<?php echo e(route('intranet.index')); ?>" class="dropdown-item">Intranet</a>
                        <a class="dropdown-item" href="<?php echo e(route('user.editData')); ?>">Panel usuario</a>
                        <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item">Salir</a>
                        <hr><br>
                        <a class="" href="<?php echo e(route('home.index')); ?>">Inicio</a>
                        <a class="" href="/#equipo">Equipo</a>
                        <a class="" href="/#servicios">Servicios</a>
                        <a class="" href="/#noticias">Noticias</a>
                        <a class="" href="/#contacto">Contacto</a>
                    </div>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'asesor')): ?>
                    <div class="dropdown" id="myDropdown">
                        <p class="logued">Bienvenido <?php echo e(auth()->user()->name); ?></p>
                        <hr><br>
                        <a href="<?php echo e(route('intranet.index')); ?>" class="dropdown-item">Intranet</a>
                        <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item">Salir</a>
                        <hr><br>
                        <a class="" href="<?php echo e(route('home.index')); ?>">Inicio</a>
                        <a class="" href="/#equipo">Equipo</a>
                        <a class="" href="/#servicios">Servicios</a>
                        <a class="" href="/#noticias">Noticias</a>
                        <a class="" href="/#contacto">Contacto</a>
                    </div>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'contable')): ?>
                    <div class="dropdown" id="myDropdown">
                        <p class="logued">Bienvenido <?php echo e(auth()->user()->name); ?></p>
                        <hr><br>
                        <a href="<?php echo e(route('intranet.index')); ?>" class="dropdown-item">Intranet</a>
                        <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item">Salir</a>
                        <hr><br>
                        <a class="" href="<?php echo e(route('home.index')); ?>">Inicio</a>
                        <a class="" href="/#equipo">Equipo</a>
                        <a class="" href="/#servicios">Servicios</a>
                        <a class="" href="/#noticias">Noticias</a>
                        <a class="" href="/#contacto">Contacto</a>
                    </div>
                    <?php endif; ?>

                    <?php endif; ?>

                    <?php if(auth()->guard()->guest()): ?>
                    <div class="dropdown" id="myDropdown">
                        <a href="<?php echo e(route('login.perform')); ?>" class="btn btn-outline-light me-2">Login</a>
                        <hr><br>
                        <a class="" href="<?php echo e(route('home.index')); ?>">Inicio</a>
                        <a class="" href="/#equipo">Equipo</a>
                        <a class="" href="/#servicios">Servicios</a>
                        <a class="" href="/#noticias">Noticias</a>
                        <a class="" href="/#contacto">Contacto</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        </div>
    </nav>
</header><?php /**PATH /var/www/mayorazgoasesoresQueue/resources/views/layouts/partials/navbar.blade.php ENDPATH**/ ?>