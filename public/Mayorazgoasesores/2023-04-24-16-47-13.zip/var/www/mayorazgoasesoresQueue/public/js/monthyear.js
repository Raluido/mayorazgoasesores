function Visibility0() {
    document.getElementById("hiddeYear").classList.add("d-block");
    document.getElementById("hiddeYear").classList.remove("d-none");
}

function Visibility1() {
    document.getElementById("form_execute").click();
}
