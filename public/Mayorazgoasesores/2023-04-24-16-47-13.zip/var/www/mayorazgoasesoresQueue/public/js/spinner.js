function spinner() {
    $("#loaderIcon").show();
}
